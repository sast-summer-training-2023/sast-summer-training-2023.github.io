import React from 'react';

const App: React.FC = () => {
  return <p>Hello, React!</p>;
};

export default App;
